const express = require("express");
const app = express();

app.use(express.json());

let cars = {};

function getDistance(lat1, lon1, lat2, lon2) {
  const R = 6371; // km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) *
    Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) *
    Math.sin(dLon / 2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

app.post("/update", (req, res) => {
  const { id, lat, lon } = req.body;
  cars[id] = { lat, lon };
  res.send("ok");
});

app.get("/distance", (req, res) => {
  const { a, b } = req.query;

  if (!cars[a] || !cars[b]) {
    return res.send("No data");
  }

  const d = getDistance(
    cars[a].lat,
    cars[a].lon,
    cars[b].lat,
    cars[b].lon
  );

  res.send(`Distance: ${d.toFixed(2)} km`);
});

app.listen(3000, () => {
  console.log("Server running on port 3000");
});
